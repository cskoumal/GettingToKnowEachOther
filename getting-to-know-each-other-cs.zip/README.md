Conner William Skoumal
Getting to Know Each Other
All content is orginal
This file is enclosed within a zip file that should be properly unzipped and should contain the files: connerpic.jpg, 
GettingToKnowEachOther.css, index.html, logo.png, and this README.md file.  With these files the provided webpage of 
index.html should properly work.
